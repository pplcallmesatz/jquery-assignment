/*
     _ _      _       _
 ___| (_) ___| | __  (_)___
/ __| | |/ __| |/ /  | / __|
\__ \ | | (__|   < _ | \__ \
|___/_|_|\___|_|\_(_)/ |___/
                   |__/

 Version: 1.6.0
  Author: Ken Wheeler
 Website: http://kenwheeler.github.io
    Docs: http://kenwheeler.github.io/slick
    Repo: http://github.com/kenwheeler/slick
  Issues: http://github.com/kenwheeler/slick/issues

 */
/* global window, document, define, jQuery, setInterval, clearInterval */
(function(factory) {
    'use strict';
    if (typeof define === 'function' && define.amd) {
        define(['jquery'], factory);
    } else if (typeof exports !== 'undefined') {
        module.exports = factory(require('jquery'));
    } else {
        factory(jQuery);
    }

}(function($) {
    'use strict';
    var Slick = window.Slick || {};

    Slick = (function() {

        var instanceUid = 0;

        function Slick(element, settings) {

            var _ = this, dataSettings;
          
        }

        return Slick;

    }());

   

    Slick.prototype.cleanUpEvents = function(data) {
            
        var _ = this;
        var ele = data;
//        console.log(ele);
        $(window).resize(function(){
                _.checkResponsive(ele);
         });

    };

  
    Slick.prototype.checkResponsive = function(data) {
        var _ = this;
         var elee = data;
        console.log(elee);
    }
    
Slick.prototype.init = function(creation) {
    
}
    $.fn.slick = function() {
        
      
        var _ = this;
          
          console.log(_);
       
       Slick.prototype.cleanUpEvents(_);
         return _;
        
    };

}));
